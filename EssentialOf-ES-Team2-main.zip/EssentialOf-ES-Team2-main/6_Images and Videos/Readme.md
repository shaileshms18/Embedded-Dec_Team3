# GIF of the output
![ezgif com-gif-maker](https://github.com/GENESIS2021Q3/EssentialOf-ES-Team2/blob/main/2_Design/ezgif.com-gif-maker%20(4).gif )


# Output

![image](https://github.com/GENESIS2021Q3/EssentialOf-ES-Team2/blob/main/2_Design/Screenshot%20(97).png)

# Output if the Voltage exceeds

![image](https://github.com/GENESIS2021Q3/EssentialOf-ES-Team2/blob/main/2_Design/Screenshot%20(98).png)

