
# Circuit Diagram

![image](https://github.com/GENESIS2021Q3/EssentialOf-ES-Team2/blob/main/2_Design/Screenshot%20(95).png)

![image](https://github.com/GENESIS2021Q3/EssentialOf-ES-Team2/blob/main/2_Design/Smooth%20Bigery-Bojo.png)

