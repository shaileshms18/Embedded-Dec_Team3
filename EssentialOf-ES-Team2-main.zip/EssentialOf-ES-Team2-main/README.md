# EssentialOf-ES-Team2 - Automatic Room Lighting System

## Folder Structure
Folder               | Description
-------------------  | -----------------------------------------
`1_Requirements`     | Documents Detailing requirements and research.
`2_Design`     | Documents Specifying design details.
`3_Implementation`   | All Code and Documentation.
`4_TestPlan`| Test Cases,implementation
`5_Report`| Contains Entire Project Report
`6_Images and Video`| Contains Images,GIF,Videos

