##REPORT

## Introduction


- The automated lighting systems are more than simply turning the lights on or off. Advanced Lighting solution adds a layer of intelligence to lighting automation and controls in Commercial Buildings. Our system examines that if a person walk into a room or near to the light, a sensor detects movement, lights turn on. After a pre-set amount of time with no motion detected (either because you’ve left the room or are head-down in those latest TPS reports) the sensor will tell the lights to shut off. By managing this lighting system it should be easier for facility managers when using our lighting controls system.

## Features


- **Greater savings** : This lighting system will save the more energy savings.


- **Controlling** : Provides a lighting control


- **Greater efficiency** : The sensor will simply turn off the lights.


- **Adds security to your home** : The lighting control also ensure that your home is much safer.


# SWOT- Strengths, and Weakness, Opportunities Threats


## Strengths

- **Saving Electricity** : The less time your lights are on, the lower your electricity bill will be. Lighting controls make it easy to know they're on only when you need them.

- **Satisfied Personal Preferences** : Lighting control systems offer intuitive flexibility. Change the amount of light depending on the time of day. (An example would be to set up dimmed lighting in the morning so that's easy on tired eyes.) Elevate your mood with bright lighting or relax with dimmed ambience; the choice is yours. Even better, you can program whatever you want at the push of a button.

- **Improved Safety** : No more fumbling in the night to make your way to the bathroom! Sensors can help you navigate the house easily and a simple press of a button on the app can turn on the lights before you even leave your bed. You can also set your bedroom lights to mimic the rising and setting sun so you wake up and fall asleep naturally.


## Weakness

- **Expensive Maintenance** : Apart from being quite costly to buy and install, home lighting control system is also expensive to maintain. Although they last very long when properly installed, they still sometimes need one or two touches to keep them from malfunctions. In such cases, you will realize that just like it is with purchasing them, buying parts necessary for proper maintenance can be pretty expensive too. For this reason, we’ve built our home lighting control system with the best materials, to keep it from easy damage.


- **Wrong Setup Can Make it Difficult To Use** : When poorly designed or installed, the home lighting control system may malfunction, not work adequately, or not work at all. We understand how frustrating this can be, and that’s why we prefer to install fully customisable systems with the right configurations to make it easy to install.

## Opportunities
@@ -37,6 +48,7 @@

# 4W's and 1'H


## WHAT

- Automatically turn on/off the lights.
@@ -56,8 +68,10 @@

# Detail requirements


## High Level Requirements


| High Level Requirements |	Description |
| ------------------------ | ----------- |
| HLR1 |	 |
| HLR2 |	 |
| HLR3 |	 |
| HLR4 |	 |
| HLR5 |	 |


## Low Level Requirements


| Low Level Requirements |	Description |
| ---------------------- | ------------- |
| HLR1_LLR1	|  |
| HLR2_LLR1	|  |
| HLR2_LLR2	|  |
| HLR3_LLR1	|  |
| HLR4_LLR1	|  |
| HLR5_LLR1 |	 |
| HLR5_LLR2 |	|


# Circuit Diagram

![image](https://github.com/GENESIS2021Q3/EssentialOf-ES-Team2/blob/main/2_Design/Screenshot%20(95).png)

![image](https://github.com/GENESIS2021Q3/EssentialOf-ES-Team2/blob/main/2_Design/Smooth%20Bigery-Bojo.png)



